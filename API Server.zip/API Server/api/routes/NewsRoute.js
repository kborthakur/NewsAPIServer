module.exports = function(app) {
    var newsAPI = require('../controllers/NewsController');
  
    // NewsAPI Routes
    app.route('/news')
      .get(newsAPI.list_all_news)
      .post(newsAPI.create_a_news);
  
  
    app.route('/news/:newsId')
      .get(newsAPI.read_a_news)
      .put(newsAPI.update_a_news)
      .delete(newsAPI.delete_a_news);
  };
  