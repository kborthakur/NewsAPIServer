var mongoose = require('mongoose');
var Schema = mongoose.Schema;


const NewsAPI = require('newsapi');
const { response } = require('express');
const newsapi = new NewsAPI('87ca7d4d4f92458a8d8e1a5dcee3f590');

var current_date = new Date(Date.now());
var old_date = new Date(Date.now() - 864e5 - 864e5);

var current_date2 = JSON.stringify(current_date);
var old_date2 = JSON.stringify(old_date);

var today = current_date2.slice(1,11);
var day_b4_yesterday = old_date2.slice(1,11);

var feed;
newsapi.v2.everything({
    q: 'food and beverage',
    sources: '',
    domains: '',
    from: day_b4_yesterday,
    to: today,
    language: 'en',
    sortBy: 'relevancy',
    page: 2
}).then(response => {
    console.log(response);
    window.feed = response;

    

});



var NewsSchema = new Schema(feed);
module.exports = mongoose.model('News', NewsSchema);